"""Submission-time static scan (a filter, not the security boundary).

Walks the submission's AST and rejects obvious escape routes: imports outside a
curated allowlist, dangerous builtins, `from x import *`, and introspection
dunders used to break out of the interpreter. This is the same check the server
runs on upload, shipped in the library so participants can run it locally.

The real isolation is the Docker sandbox on the match worker. An AST scan can be
defeated by a determined attacker; its job is to catch accidents and obvious
abuse early with a readable reason, before a submission ever reaches a sandbox.
"""

import ast

# torch is deliberately absent: it is not installed in the sandbox (importing it is
# slow and the limits are tight). Train with torch anywhere, then run the forward
# pass with numpy / papersseum.nn using weights embedded via `papersseum pack`.
ALLOWED_IMPORTS = {
    "numpy", "math", "random", "itertools", "collections", "functools",
    "heapq", "bisect", "typing", "dataclasses", "enum", "json", "copy",
    "operator", "statistics", "array", "re", "string", "time", "abc",
    "fractions", "decimal", "numbers", "contextlib",
    "papersseum",
}

BANNED_CALLS = {
    "eval", "exec", "compile", "open", "__import__", "input", "breakpoint",
    "execfile", "globals", "locals", "getattr", "setattr", "delattr", "vars",
}

BANNED_ATTRS = {
    "__subclasses__", "__globals__", "__code__", "__bases__", "__mro__",
    "__builtins__", "__reduce__", "__reduce_ex__", "__getattribute__",
}

MAX_BYTES = 1_000_000

# Direct loaders on these modules can execute pickled code or read arbitrary
# paths. Weights go through `papersseum.load_weights` instead.
LOADER_MODULES = {"numpy", "torch"}
BANNED_LOADERS = {"load", "loadtxt", "genfromtxt", "fromfile", "hub"}


def _import_msg(name, top):
    if top == "torch":
        return ("import 'torch' is not allowed: it is not installed in the sandbox. Train with torch "
                "locally, then run inference with numpy / papersseum.nn (see `papersseum pack`)")
    return f"import '{name}' is not allowed"


def scan_source(src, filename="<submission>"):
    """Return {ok: bool, violations: [{line, kind, detail}]}."""
    violations = []
    if len(src.encode("utf-8", "ignore")) > MAX_BYTES:
        violations.append((0, "size", f"source exceeds {MAX_BYTES} bytes"))

    try:
        tree = ast.parse(src, filename)
    except SyntaxError as e:
        return {"ok": False, "violations": [{"line": e.lineno or 0, "kind": "syntax", "detail": str(e)}]}

    aliases = {}   # local name -> top-level module, for LOADER_MODULES
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] in LOADER_MODULES:
                    aliases[(a.asname or a.name).split(".")[0]] = a.name.split(".")[0]
                top = a.name.split(".")[0]
                if top not in ALLOWED_IMPORTS:
                    violations.append((node.lineno, "import", _import_msg(a.name, top)))
        elif isinstance(node, ast.ImportFrom):
            if node.names and node.names[0].name == "*":
                violations.append((node.lineno, "import", "'from ... import *' is not allowed"))
            top = (node.module or "").split(".")[0]
            if top and top not in ALLOWED_IMPORTS:
                violations.append((node.lineno, "import", _import_msg(node.module, top)))
        elif isinstance(node, ast.Call):
            f = node.func
            if isinstance(f, ast.Name) and f.id in BANNED_CALLS:
                violations.append((node.lineno, "call", f"call to '{f.id}' is not allowed"))
            if (isinstance(f, ast.Name) and f.id == "load_weights") or \
                    (isinstance(f, ast.Attribute) and f.attr == "load_weights"):
                violations.append((node.lineno, "weights",
                                   "load_weights reads a file, and only a single .py file is uploaded; "
                                   "embed your weights with `papersseum pack` and use unpack_weights"))
        elif isinstance(node, ast.Attribute):
            root = node.value
            while isinstance(root, ast.Attribute):
                root = root.value
            if (node.attr in BANNED_LOADERS and isinstance(root, ast.Name)
                    and aliases.get(root.id) in LOADER_MODULES):
                violations.append((node.lineno, "call",
                                   f"'{node.attr}' on {aliases[root.id]} is not allowed; "
                                   "use papersseum.load_weights"))
            if node.attr in BANNED_ATTRS:
                violations.append((node.lineno, "attr", f"attribute '{node.attr}' is not allowed"))
        elif isinstance(node, ast.Name):
            if node.id in BANNED_ATTRS:
                violations.append((node.lineno, "name", f"use of '{node.id}' is not allowed"))

    violations.sort(key=lambda v: (v[0], v[1]))
    return {"ok": not violations,
            "violations": [{"line": l, "kind": k, "detail": d} for l, k, d in violations]}


def scan_file(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        return scan_source(fh.read(), str(path))
